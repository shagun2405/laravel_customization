@extends('galaxy::layouts.master')

@section('page_title')
    {{ __('galaxy::app.customer.login') }}
@stop

@section('content')


    <div class="therapist-panel" style="    width: fit-content;
    transform: translate(50%);
    margin-top: 4%;">
        <a href="{{ route('shop.therapist.login.index') }}">
            <div class="image_container" style="float: right; text-align:center; font-size: 20px;">
                <div class="container_image">
                    <img src="{{ asset('/themes/galaxy/assets/images/office_365.png') }}" style="width: 200px; height: 67px;">
                </div>
                <div class="text">
                    <h1>Therapists Login</h1>
                </div>
            </div>
        </a>    
        <div class="form-container" style="text-align: center; font-size: 15px; margin-top: 13%;">
            <img class="h-14 mx-auto" src="{{ asset('/themes/galaxy/assets/images/bankid_logo.png') }}" alt="bankid_logo">
            <div style="margin-top:2%;">
                Starta BankID-appen och valj alternativet for <br />
                QR-Kod. Scanna sedan koden nedan.
                <!-- <span>{{ __('galaxy::app.customer.bankid_login_text') }}</span> -->
            </div> 
            <form method="POST" action="" @submit.prevent="onSubmit">
                @csrf  
                <div class="control-group">
                    <img src="@php echo $qrImage @endphp" class="h-22 mx-auto"/>
                </div>
            </form>

        </div>     

        <a href="{{ route('shop.customer.clinic.therapist.company') }}">Login as Test</a>

    </div>

@stop

@push('javascript')
    <script>
        $(document).ready(function(){
            $.ajax({
               type:'GET',
               url:'{{ route('shop.customer.login.bankid') }}',
               data:'_token = <?php echo csrf_token() ?>',
               success:function(data) {
                  console.log('hjhjjh');
               }
            });
        });
    </script>
@endpush