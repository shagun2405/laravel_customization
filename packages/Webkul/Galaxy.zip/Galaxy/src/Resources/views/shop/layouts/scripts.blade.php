<script type="text/javascript" src="{{ asset(mix('/js/manifest.js', 'themes/galaxy/assets')) }}"></script>

<script type="text/javascript" src="{{ asset(mix('/js/galaxy.js', 'themes/galaxy/assets')) }}"></script>

<script type="text/javascript" src="{{ asset(mix('/js/components.js', 'themes/galaxy/assets')) }}"></script>

<script type="text/javascript">
   



</script>
