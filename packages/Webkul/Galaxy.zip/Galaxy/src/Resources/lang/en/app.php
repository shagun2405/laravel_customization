<?php

return [
    'therapist'         => [
        'galaxy' => [
            'title' => 'Therapist Sign In',
            'patient_view_title' => 'Patient Data',
        ],
    ],

    'customer' =>[
        'login' => 'User Sign In',
        'clinic' => [
            'therapist' => [
                'message'    => 'Message',
                'payment'    => 'Payment',
                'services'   => 'Services',
                'slots'      => 'Slots',
                'company'    => 'Company',
            ]
        ]
    ],
  
    'header' =>[
        'account' => 'Account',
        'sign-in' => 'Sign-In',
        'sign-up' => 'Sign-Up'
    ],

    'checkout' => [
        'order-success' => 'Order Placed Successfully!!!'
    ]
];
